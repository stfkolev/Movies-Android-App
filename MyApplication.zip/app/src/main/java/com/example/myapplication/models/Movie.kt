package com.example.myapplication.models

data class Movie(
        val title: String,
        val description: String,
        val year: Int
)